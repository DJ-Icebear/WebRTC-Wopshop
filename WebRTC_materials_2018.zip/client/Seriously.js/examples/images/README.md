# Image Credits

## Color Your Life
https://www.flickr.com/photos/uaeincredible/231011361/
by "Capture Queen"
Creative Commons Attribution 2.0 Generic (CC BY 2.0)

## Pinwheel Bot
https://www.flickr.com/photos/ittybittiesforyou/4837847601/
by "Jenn and Tony Bot"
Attribution-NonCommercial 2.0 Generic (CC BY-NC 2.0)
